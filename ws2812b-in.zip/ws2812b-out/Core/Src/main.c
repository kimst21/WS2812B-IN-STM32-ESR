/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * - STM32?? WS2812 NeoPixel LED�????? ?��?��?��?�� ?��로그?��?��?��?��.
  * - DMA�????? ?��?��?��?�� PWM ?��?���????? ?��?��?���?????, ?���????? ?��?�� ?��?�� LED�????? ?��?��?��?��?��.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/**
 * @brief PixelRGB_t : RGB LED ?��?���????? ?��?�� 24비트 RGB 구조�?????
 * @brief PixelRGBW_t : RGBW LED ?��?���????? ?��?�� 32비트 RGBW 구조�?????
 */
typedef union
{
  struct
  {
    uint8_t b;
    uint8_t r;
    uint8_t g;
  } color;
  uint32_t data;
} PixelRGB_t;

typedef union
{
  struct
  {
    uint8_t w;
    uint8_t b;
    uint8_t r;
    uint8_t g;
  } color;
  uint32_t data;
} PixelRGBW_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define NEOPIXEL_ZERO 34  // PWM �????? (0?�� ?��?�� ?��)
#define NEOPIXEL_ONE  67  // PWM �????? (1?�� ?��?�� ?��)
#define NUM_PIXELS    10  // LED 개수
#define DMA_BUFF_SIZE (NUM_PIXELS * 24) + 1 // DMA 버퍼 ?���?????
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**
 * @brief PWM DMA ?��?�� ?���????? 콜백
 * @param htim2 : ???���????? ?��?��?��
 */
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim4)
{
  HAL_TIM_PWM_Stop_DMA(htim4, TIM_CHANNEL_1); // DMA ?��?�� 종료 ?�� PWM 중단
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  PixelRGB_t pixel[NUM_PIXELS] = {0};  // LED ?��?? ?��?��?�� 배열
  uint32_t dmaBuffer[DMA_BUFF_SIZE] = {0}; // DMA ?��?��?�� 버퍼
  uint32_t *pBuff;                     // DMA 버퍼 ?��?��?��
  int i, j, k;                         // 루프 �??????��
  uint16_t stepSize;                   // ?��?�� �??????�� ?���????? ?���?????
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  k = 0;                            // ?��?�� �??????�� ?��?��?�� 초기?��
  stepSize = 4;                     // ?��?�� �??????�� ?���????? ?���????? ?��?��
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    // LED ?��?��?�� ?��?��?��?��
  while(1)
  {
    for (i = NUM_PIXELS - 1; i > 0; i--)
    {
      pixel[i].data = pixel[i - 1].data; // ?��?�� LED?�� ?��?��?���????? ?��?�� LED�????? 복사
    }

    // ?��?�� 계산 (컬러 ?��?��?��?��)
    if (k < 255)
    {
      pixel[0].color.g = 254 - k; // 초록?�� 감소
      pixel[0].color.r = k + 1;   // 빨간?�� 증�?
      pixel[0].color.b = 0;       // ?��???�� ?���?????
    }
    else if (k < 510)
    {
      pixel[0].color.g = 0;            // 초록?�� ?���?????
      pixel[0].color.r = 509 - k;      // 빨간?�� 감소
      pixel[0].color.b = k - 254;      // ?��???�� 증�?
    }
    else if (k < 765)
    {
      pixel[0].color.g = k - 509;      // 초록?�� 증�?
      pixel[0].color.r = 0;            // 빨간?�� ?���?????
      pixel[0].color.b = 764 - k;      // ?��???�� 감소
    }
    k = (k + stepSize) % 765;          // ?��?�� �??????�� 주기 조정

    // LED 밝기 조정 (1/4�????? 감소)
    pixel[0].color.g >>= 2;
    pixel[0].color.r >>= 2;
    pixel[0].color.b >>= 2;

    // DMA 버퍼?�� PWM ?��?��?�� �?????�?????
    pBuff = dmaBuffer;
    for (i = 0; i < NUM_PIXELS; i++)
    {
      for (j = 23; j >= 0; j--)
      {
        // �????? 비트�????? PWM 값으�????? �??????��
        if ((pixel[i].data >> j) & 0x01)
          *pBuff = NEOPIXEL_ONE;
        else
          *pBuff = NEOPIXEL_ZERO;
        pBuff++;
      }
    }
    dmaBuffer[DMA_BUFF_SIZE - 1] = 0; // 마�?�????? DMA ?��?��?��?�� 0?���????? ?��?��

    // DMA�????? ?��?�� PWM ?��?�� ?��?��
    HAL_TIM_PWM_Start_DMA(&htim4, TIM_CHANNEL_1, dmaBuffer, DMA_BUFF_SIZE);
    HAL_Delay(10); // 10ms ??�?????
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
